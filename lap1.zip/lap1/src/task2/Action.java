package task2; 

public abstract class Action {
	public abstract boolean isNoOp();
}