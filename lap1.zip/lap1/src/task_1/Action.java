package task_1; 

public abstract class Action {
	public abstract boolean isNoOp();
}